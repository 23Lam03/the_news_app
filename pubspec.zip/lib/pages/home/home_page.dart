import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:news/provider/news_provider.dart';
import 'package:news/provider/sport_provider.dart';
import 'package:provider/provider.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final Map<int, bool> _selectedSports = {};

  @override
  void initState() {
    super.initState();
    context.read<SportProvider>().fetchSport();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xffFEBB4B),
              ),
              child: IconButton(
                onPressed: () {},
                icon: const Icon(Icons.menu),
              ),
            ),
            Container(
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xffFEBB4B),
              ),
              child: IconButton(
                onPressed: () {},
                icon: const Icon(Icons.search),
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 13),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Thể thao',
                    style: GoogleFonts.actor(
                      fontWeight: FontWeight.w400,
                      fontSize: 30,
                      color: const Color(0xff000000),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {},
                    child: Text(
                      'view all',
                      style: GoogleFonts.actor(
                        fontWeight: FontWeight.w400,
                        fontSize: 15,
                        color: const Color(0xffFFA100),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Consumer<SportProvider>(
              builder: (context, provider, child) {
                if (provider.sports.isEmpty) {
                  return const Center(child: CircularProgressIndicator());
                }
                return ListView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: 4,
                  itemBuilder: (context, index) {
                    final sports = provider.sports[index];
                    return ListTile(
                      leading: Container(
                        width: 121,
                        height: 100,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      title: Text(
                        sports.title,
                        style: GoogleFonts.actor(
                          fontWeight: FontWeight.w400,
                          fontSize: 20,
                          color: const Color(0xffFFBD4A),
                        ),
                      ),
                      subtitle: Text(
                        sports.description,
                        style: GoogleFonts.actor(
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                          color: const Color(0xff000000),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Thời sự',
                  style: GoogleFonts.actor(
                    fontWeight: FontWeight.w400,
                    fontSize: 30,
                    color: const Color(0xff000000),
                  ),
                ),
                GestureDetector(
                  onTap: () {},
                  child: Text(
                    'view all',
                    style: GoogleFonts.actor(
                      fontWeight: FontWeight.w400,
                      fontSize: 15,
                      color: const Color(0xffFFA100),
                    ),
                  ),
                ),
              ],
            ),
            Consumer<NewsProvider>(
              builder: (context, provider, child) {
                if (provider.news.isEmpty) {
                  return const Center(child: CircularProgressIndicator());
                }
                return ListView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: 4,
                  itemBuilder: (context, index) {
                    final news = provider.news[index];
                    return ListTile(
                      leading: Container(
                        width: 121,
                        height: 100,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      title: Text(
                        news.title,
                        style: GoogleFonts.actor(
                          fontWeight: FontWeight.w400,
                          fontSize: 20,
                          color: const Color(0xffFFBD4A),
                        ),
                      ),
                      subtitle: Text(
                        news.description,
                        style: GoogleFonts.actor(
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                          color: const Color(0xff000000),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
