import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:news/provider/sport_provider.dart';
import 'package:provider/provider.dart';

class SportPage extends StatelessWidget {
  const SportPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Container(
          alignment: Alignment.center,
          width: double.infinity,
          height: 74,
          color: const Color(0xffFFBA4B),
          child: Text(
            'Thể thao',
            style: GoogleFonts.actor(
              fontWeight: FontWeight.w400,
              fontSize: 30,
              color: const Color(0xffFFFFFF),
            ),
          ),
        ),
      ),
      body: Consumer<SportProvider>(
        builder: (context, provider, child) {
          if (provider.sports.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }
          return ListView.builder(
            itemCount: provider.sports.length,
            itemBuilder: (BuildContext context, int index) {
              final sports = provider.sports[index];
              return ListTile(
                leading: Container(
                  width: 121,
                  height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                title: Text(
                  sports.title,
                  style: GoogleFonts.actor(
                    fontWeight: FontWeight.w400,
                    fontSize: 20,
                    color: const Color(0xffFFBD4A),
                  ),
                ),
                subtitle: Text(
                  sports.description,
                  style: GoogleFonts.actor(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: const Color(0xff000000),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
