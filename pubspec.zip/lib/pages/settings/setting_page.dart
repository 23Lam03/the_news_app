import 'package:flutter/material.dart';
import 'package:news/models/category_model.dart';
import 'package:news/provider/setting_provider.dart';
import 'package:provider/provider.dart';

class SettingPage extends StatefulWidget {
  const SettingPage({super.key});
  @override
  State<SettingPage> createState() => _SettingPageState();
}

class _SettingPageState extends State<SettingPage> {
  late Future<List<CategoryModel>> _categoriesFuture;
  final Map<int, bool> _selectedCategories = {};
  @override
  void initState() {
    super.initState();
    _categoriesFuture = context.read<SettingsProvider>().getCategories();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Setting Page'),
      ),
      body: FutureBuilder(
        future: _categoriesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot
              .hasData) //snapshot.hasData kiểm tra xem có chứa dữ liệu hợp lệ hay không.
          {
            List<CategoryModel> categories =
                snapshot.data as List<CategoryModel>;

            for (int i = 0; i < categories.length; i++) {
              _selectedCategories[i] = _selectedCategories[i] ?? false;
            }

            return GridView.builder(
              padding: const EdgeInsets.all(10),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 3 / 1,
              ),
              itemCount: categories.length,
              itemBuilder: (BuildContext context, int index) {
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    color: Colors.primaries[index % Colors.primaries.length],
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: CheckboxListTile(
                    checkboxShape: const CircleBorder(),
                    activeColor: Colors.white,
                    checkColor: Colors.white,
                    contentPadding: EdgeInsets.zero,
                    title: Text(
                      categories[index].name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    value: _selectedCategories[index],
                    onChanged: (newValue) {
                      setState(() {
                        _selectedCategories[index] = newValue ?? false;
                      });
                    },
                    controlAffinity: ListTileControlAffinity.trailing,
                  ),
                );
              },
            );
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          return const Center(child: Text('No categories available.'));
        },
      ),
    );
  }
}
