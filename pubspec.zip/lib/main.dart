import 'package:flutter/material.dart';
import 'package:news/apps/my_app.dart';

void main(List<String> args) {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}
