import 'package:dio/dio.dart';
import 'package:news/models/news_model.dart';

class NewsRepo {
  static final dio = Dio();

  static Future<List<NewsModel>> getAllNews() async {
    final response = await dio.get(
        'https://apiforlearning.zendvn.com/api/categories_news/2/articles?offset=0&limit=10&sort_by=id&sort_dir=desc');

    if (response.statusCode == 200) {
      List data = response.data;
      List<NewsModel> news = data.map((e) => NewsModel.fromMap(e)).toList();
      return news;
    }

    return [];
  }
}
