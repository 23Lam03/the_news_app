import 'package:flutter/material.dart';
import 'package:news/models/sport_model.dart';
import 'package:news/repository/sport_repo.dart';

class SportProvider extends ChangeNotifier {
  List<SportModel> _sports = [];

  List<SportModel> get sports => _sports;

  Future<void> fetchSport() async {
    _sports = await SportRepo.getAllSport();
    notifyListeners();
  }
}
