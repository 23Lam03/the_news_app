import 'package:flutter/material.dart';
import 'package:news/models/category_model.dart';
import 'package:news/repository/category_repo.dart';

class SettingsProvider extends ChangeNotifier {
  Future<List<CategoryModel>> getCategories() async {
    List<CategoryModel> categories = await CategoryRepo.getAllCategories();
    return categories;
  }
}
