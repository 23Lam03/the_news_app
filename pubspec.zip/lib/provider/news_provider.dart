import 'package:flutter/material.dart';
import 'package:news/models/news_model.dart';
import 'package:news/repository/new_repo.dart';

class NewsProvider extends ChangeNotifier {
  List<NewsModel> _news = [];

  List<NewsModel> get news => _news;

  Future<void> fetchNews() async {
    _news = await NewsRepo.getAllNews();
    notifyListeners();
  }
}
