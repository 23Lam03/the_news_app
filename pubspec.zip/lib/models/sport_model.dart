import 'dart:convert';

// ignore_for_file: public_member_api_docs, sort_constructors_first
class SportModel {
  int id;
  String title;
  String description;
  String content;
  String thumb;
  SportModel({
    required this.id,
    required this.title,
    required this.description,
    required this.content,
    required this.thumb,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'title': title,
      'description': description,
      'content': content,
      'thumb': thumb,
    };
  }

  factory SportModel.fromMap(Map<String, dynamic> map) {
    return SportModel(
      id: map['id'] as int,
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      content: map['content'] ?? '',
      thumb: map['thumb'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory SportModel.fromJson(String source) =>
      SportModel.fromMap(json.decode(source) as Map<String, dynamic>);
}
